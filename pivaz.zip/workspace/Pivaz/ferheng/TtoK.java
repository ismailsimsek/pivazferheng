package ferheng;

import javax.swing.JPanel;

import java.awt.Dimension;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JTextField;
import java.awt.Rectangle;
import java.awt.Font;
import java.util.Vector;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;

import locallib.DataQuery;
import locallib.InitPivaz;

public class TtoK extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane2 = null;
	private JTextField jTextField1 = null;
	private JList jList1 = null;
	private JLabel jLabel6 = null;
	private JLabel jLabel11 = null;
	private JLabel jLabel21 = null;
	private JScrollPane jScrollPane2 = null;
	private JTextArea jTextArea1 = null;
	private JScrollPane jScrollPane11 = null;
	private JButton jButton8 = null;
	private Frame parent;

	/**
	 * @param owner
	 */
	public TtoK(Frame owner) {
		super(owner);
		initialize();
		parent=owner;
		parent.setEnabled(false);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(357, 281);
		this.setContentPane(getJContentPane2());
		this.setTitle("T�rk�e K�rt�e");			
		this.setResizable(false);
		this.setPreferredSize(new Dimension(357, 281));
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowOpened(java.awt.event.WindowEvent e) {    
				System.out.println("windowOpened()"); // TODO Auto-generated Event stub windowOpened()
			}
			public void windowClosing(java.awt.event.WindowEvent e) {
				parent.setEnabled(true);
				System.out.println("windowClosing()"); // TODO Auto-generated Event stub windowClosing()
			}
		});
	}

	/**
	 * This method initializes jContentPane2	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane2() {
		if (jContentPane2 == null) {
			jLabel21 = new JLabel();
			jLabel21.setBounds(new Rectangle(182, 49, 110, 20));
			jLabel21.setText("K�rt�e Kar\u015f\u0131l\u0131k");
			jLabel21.setForeground(InitPivaz.getTextColor());
			jLabel11 = new JLabel();
			jLabel11.setBounds(new Rectangle(10, 49, 129, 20));
			jLabel11.setText("T�rk�e S�zc�kler");
			jLabel11.setForeground(InitPivaz.getTextColor());
			jLabel6 = new JLabel();
			jLabel6.setBounds(new Rectangle(10, 0, 72, 20));
			jLabel6.setText("Kelime");
			jLabel6.setForeground(InitPivaz.getTextColor());
			jContentPane2 = new JPanel();
			jContentPane2.setLayout(null);
			jContentPane2.setBackground(InitPivaz.getBackColor());
			jContentPane2.add(getJTextField1(), null);
			jContentPane2.add(getJList1(), null);
			jContentPane2.add(jLabel6, null);
			jContentPane2.add(jLabel11, null);
			jContentPane2.add(jLabel21, null);
			jContentPane2.add(getJScrollPane2(), null);
			jContentPane2.add(getJScrollPane11(), null);
			jContentPane2.add(getJButton8(), null);
		}
		return jContentPane2;
	}

	/**
	 * This method initializes jTextField1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField1() {
		if (jTextField1 == null) {
			jTextField1 = new JTextField();
			jTextField1.setBounds(new Rectangle(9, 19, 224, 28));
			jTextField1.setFont(new Font("Dialog", Font.BOLD, 13));
			jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyReleased(java.awt.event.KeyEvent e) {
					if(!(jTextField1.getText().isEmpty())){					
						jList1.setListData(DataQuery.SearchTurkishWords(jTextField1.getText()));
						jList1.setSelectedIndex(0);						
					} else {
						jList1.setListData(new Vector<String>());
						jTextArea1.setText("");
					}
					System.out.println("keyReleased()"); // TODO Auto-generated Event stub keyReleased()
				}
			});
		}
		return jTextField1;
	}

	/**
	 * This method initializes jList1	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJList1() {
		if (jList1 == null) {
			jList1 = new JList();
			jList1.setFont(new Font("Dialog", Font.BOLD, 13));
			jList1.addMouseListener(new java.awt.event.MouseAdapter() {   
				public void mouseClicked(java.awt.event.MouseEvent e) {    
					if (jList1.getSelectedValue()!= null) 
						jTextField1.setText(jList1.getSelectedValue().toString());
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
				}
			
			});
			jList1.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
				public void valueChanged(javax.swing.event.ListSelectionEvent e) {
					if (jList1.getSelectedValue()!= null) {
						jTextArea1.setText(DataQuery.SearchTurkishWord(jList1.getSelectedValue().toString()));
						}
						else jTextArea1.setText("");
					System.out.println("valueChanged()"); // TODO Auto-generated Event stub valueChanged()
				}
			});
		}
		return jList1;
	}

	/**
	 * This method initializes jTextArea1	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea1() {
		if (jTextArea1 == null) {
			jTextArea1 = new JTextArea();
			jTextArea1.setFont(new Font("Dialog", Font.BOLD, 13));
			jTextArea1.setLineWrap(true);
			jTextArea1.setRows(3);
			jTextArea1.setWrapStyleWord(true);
			jTextArea1.setColumns(3);
		}
		return jTextArea1;
	}

	/**
	 * This method initializes jScrollPane2	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane2() {
		if (jScrollPane2 == null) {
			jScrollPane2 = new JScrollPane(getJTextArea1());
			jScrollPane2.setBounds(new Rectangle(181, 70, 162, 170));
			jScrollPane2.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED), BorderFactory.createBevelBorder(BevelBorder.RAISED)));
			jScrollPane2.setViewportView(getJTextArea1());
		}
		return jScrollPane2;
	}

	/**
	 * This method initializes jScrollPane11	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane11() {
		if (jScrollPane11 == null) {
			jScrollPane11 = new JScrollPane(getJList1());
			jScrollPane11.setBounds(new Rectangle(9, 70, 163, 170));
			jScrollPane11.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED), BorderFactory.createBevelBorder(BevelBorder.RAISED)));
		}
		return jScrollPane11;
	}

	/**
	 * This method initializes jButton8	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton8() {
		if (jButton8 == null) {
			jButton8 = new JButton();
			jButton8.setBounds(new Rectangle(254, 10, 86, 40));
			jButton8.setText("Tamam");
			jButton8.setBackground(InitPivaz.getButonColor());
			jButton8.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {					
					parent.setEnabled(true);
					setVisible(false);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton8;
	}

}
