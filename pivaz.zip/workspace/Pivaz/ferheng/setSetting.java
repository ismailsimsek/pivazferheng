package ferheng;

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JButton;
import java.awt.Rectangle;

import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import java.awt.Dimension;
import javax.swing.JMenu;

import locallib.InitPivaz;

public class setSetting extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton jButton = null;
	private JLabel jLabel = null;
	private JButton jButton1 = null;
	private JButton jButton2 = null;
	private JMenuBar jJMenuBar = null;
	private Frame parent;
	private JMenu Test = null;

	/**
	 * @param owner
	 */
	public setSetting(Frame owner) {
		super(owner);
		initialize();
		parent=owner;
		parent.setEnabled(false);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setTitle("Set Colours");
		this.setMinimumSize(new Dimension(300, 200));
		this.setJMenuBar(getJJMenuBar());
		this.setContentPane(getJContentPane());
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				parent.setEnabled(true);
				System.out.println("windowClosing()"); // TODO Auto-generated Event stub windowClosing()
			
			}
		});
	}

	/**
	 * This method initializes jContentPane	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(13, 80, 123, 35));
			jLabel.setText("Text colour");
			jLabel.setBackground(InitPivaz.getBackColor());
			jLabel.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
						Color c = JColorChooser.showDialog(setSetting.this,
				            "Choose a color...",jLabel.getForeground());
				        if (c != null)
				        jLabel.setForeground(c);
				        InitPivaz.setTextColor(c);
				}
			});
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setBackground(InitPivaz.getBackColor());
			jContentPane.add(getJButton(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(getJButton1(), null);
			jContentPane.add(getJButton2(), null);
			jContentPane.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
					Color c = JColorChooser.showDialog(setSetting.this,
				            "Choose a color...",jContentPane.getBackground());
				        if (c != null)
				        jContentPane.setBackground(c);
				        InitPivaz.setBackColor(c);
				}
			});
		}
		return jContentPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(11, 21, 122, 47));
			jButton.setText("Buton colour");
			jButton.setBackground(InitPivaz.getButonColor());
			jButton.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
					Color c = JColorChooser.showDialog(setSetting.this,
				            "Choose a color...",jButton.getBackground());
				        if (c != null)
				        jButton.setBackground(c);
				        InitPivaz.setButonColor(c);
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(179, 50, 92, 33));
			jButton1.setText("Cancel");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					parent.setEnabled(true);
					setVisible(false);					
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton1;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(179, 94, 92, 33));
			jButton2.setText("Save");
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					InitPivaz.saveNewSettings();
					parent.setEnabled(true);
					setVisible(false);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton2;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.setBackground(InitPivaz.getMenuColor());
			jJMenuBar.setPreferredSize(new Dimension(0, 25));
			jJMenuBar.add(getTest());
			jJMenuBar.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
					Color c = JColorChooser.showDialog(setSetting.this,
				            "Choose a color...",jJMenuBar.getBackground());
				        if (c != null)
				        jJMenuBar.setBackground(c);
				        InitPivaz.setMenuColor(c);
				        
				}
			});
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes Test	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getTest() {
		if (Test == null) {
			Test = new JMenu();
			Test.setText("Test");
		}
		return Test;
	}

}
