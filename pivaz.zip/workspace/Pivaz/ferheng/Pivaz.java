package ferheng;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Rectangle;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JFrame;
import javax.swing.JDialog;

import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.ImageIcon;

import locallib.DataQuery;
import locallib.InitPivaz;

public class Pivaz {
	
	public InitPivaz pSettings = null;
	public DataQuery dbConn = null;
	//my data
	static int screenheight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight()-281;  //  @jve:decl-index=0:
	static int screenwidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()-357;  //  @jve:decl-index=0:
	

		
	public Pivaz() {
		super();
		pSettings=new InitPivaz();
		dbConn=new DataQuery();
		// TODO Auto-generated constructor stub
	}

	private JFrame jFrame = null;

	private JDialog aboutDialog = null;  //  @jve:decl-index=0:visual-constraint="265,0"

	private JMenuBar jJMenuBar = null;

	private JMenu fileMenu = null;

	private JMenuItem jMenuItem = null;

	private JMenuItem jMenuItem1 = null;

	private JMenuItem exitMenuItem = null;

	private JMenu editMenu = null;

	private JMenuItem jMenuItem2 = null;

	private JMenu helpMenu = null;

	private JMenuItem aboutMenuItem = null;

	private JPanel jContentPane = null;

	private JButton jButton = null;

	private JButton jButton1 = null;

	private JPanel aboutContentPane = null;

	private JLabel aboutVersionLabel = null;

	private JLabel jLabel12 = null;
	

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.setBackground(InitPivaz.getMenuColor());
			jJMenuBar.setPreferredSize(new Dimension(101, 16));
			jJMenuBar.add(getFileMenu());
			jJMenuBar.add(getEditMenu());
			jJMenuBar.add(getHelpMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes fileMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFileMenu() {
		if (fileMenu == null) {
			fileMenu = new JMenu();
			fileMenu.setText("File");
			fileMenu.add(getJMenuItem());
			fileMenu.add(getJMenuItem1());
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem() {
		if (jMenuItem == null) {
			jMenuItem = new JMenuItem();
			jMenuItem.setText("T�rk�e - K�rt�e");
			jMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					TtoK aboutDialog =new TtoK(jFrame);
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20,20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jMenuItem;
	}

	/**
	 * This method initializes jMenuItem1	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem1() {
		if (jMenuItem1 == null) {
			jMenuItem1 = new JMenuItem();
			jMenuItem1.setText("Kurd� - Tirk�");
			jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					KtoT kurToTur =new KtoT(jFrame);
					kurToTur.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20,20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					kurToTur.setLocation(loc);
					kurToTur.setVisible(true);
				}
			});
		}
		return jMenuItem1;
	}

	/**
	 * This method initializes exitMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getExitMenuItem() {
		if (exitMenuItem == null) {
			exitMenuItem = new JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return exitMenuItem;
	}

	/**
	 * This method initializes editMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getEditMenu() {
		if (editMenu == null) {
			editMenu = new JMenu();
			editMenu.setText("Edit");
			editMenu.add(getJMenuItem2());
		}
		return editMenu;
	}

	/**
	 * This method initializes jMenuItem2	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem2() {
		if (jMenuItem2 == null) {
			jMenuItem2 = new JMenuItem();
			jMenuItem2.setText("Preferences");
			jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					setSetting setting = new setSetting(jFrame);
					setting.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					setting.setLocation(loc);
					setting.setVisible(true);
					
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jMenuItem2;
	}

	/**
	 * This method initializes helpMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getHelpMenu() {
		if (helpMenu == null) {
			helpMenu = new JMenu();
			helpMenu.setText("Help");
			helpMenu.add(getAboutMenuItem());
		}
		return helpMenu;
	}

	/**
	 * This method initializes aboutMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAboutMenuItem() {
		if (aboutMenuItem == null) {
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			aboutMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JDialog aboutDialog = getAboutDialog();
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
				}
			});
		}
		return aboutMenuItem;
	}

	/**
	 * This method initializes jContentPane	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setBackground(InitPivaz.getBackColor());
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJButton1(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(5, 6, 100, 45));
			jButton.setText("Tirk� - Kurd�");
			jButton.setBackground(InitPivaz.getButonColor());
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					TtoK aboutDialog =new TtoK(jFrame);
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20,20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(111, 5, 100, 45));
			jButton1.setText("Kurd� - Tirk�");
			jButton1.setBackground(InitPivaz.getButonColor());
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					KtoT kurToTur =new KtoT(jFrame);
					kurToTur.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20,20);
					if(loc.getX()<0)
						loc.x=0;
					else if(loc.getX()>screenwidth)
						loc.x=screenwidth;					
					if(loc.getY()<0)
						loc.y=0;
					else if(loc.getY()>screenheight)
						loc.y=screenheight;
					kurToTur.setLocation(loc);
					kurToTur.setVisible(true);				
					}
			});
		}
		return jButton1;
	}

	/**
	 * This method initializes aboutContentPane	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getAboutContentPane() {
		if (aboutContentPane == null) {
			jLabel12 = new JLabel();
			jLabel12.setBounds(new Rectangle(155, 6, 95, 98));
			jLabel12.setIcon(new ImageIcon(getClass().getResource("/ferheng/pivaz.gif")));
			aboutVersionLabel = new JLabel();
			aboutVersionLabel.setBounds(new Rectangle(8, 5, 243, 252));
			aboutVersionLabel.setText("<html><br><u>Pivaz  Version  1.0.6    � <br>" + 
					"by memiiso</u><br><br><br>" + 
					" Dijital bir T�rk�e-K�rt�e <br> K�rt�e-T�rk�e " +
					"s�zl�k olan <br>Yekbun\'un s�zl�\u011f�," + 
					"Doz yay\u0131n evinin 1998 ve 2002 y\u0131llar\u0131nda" +
					"yay\u0131mlanan cep s�zl�\u011f�" + 
					"(ISBN 975-6876-34-4) esas al\u0131narak, Urfa\'da haz\u0131rland\u0131." + 
					"Yakla\u015f\u0131k 25.000  kelime ve deyim  i�eren" + 
					"s�zl�\u011f�n �ns�zleri ve  k\u0131saltmalar\u0131" + 
					"yine Doz yay\u0131n evinin  s�zl�\u011f�ne aittir." + 
					"De\u011ferli ve g�zel halk\u0131m\u0131za faydal\u0131 olmas\u0131 " +
					"dileklerimle... " +
					"" + 
					"pivaz s�zl�g� kulan��l� bir aray�z " +
					"sa�lamak ve k�rt�e nin ��renilmesine " +
					"katk�da bulunmak i�in kar amac� " +
					"g�d�lmeden geli�tirilmi�tir </html>");
			aboutVersionLabel.setVerticalAlignment(SwingConstants.TOP);
			aboutVersionLabel.setHorizontalAlignment(SwingConstants.LEFT);
			aboutContentPane = new JPanel();
			aboutContentPane.setLayout(null);
			aboutContentPane.add(aboutVersionLabel, null);
			aboutContentPane.add(jLabel12, null);
		}
		return aboutContentPane;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Pivaz application = new Pivaz();
				application.getJFrame().setVisible(true);
			}
		});
	}

	/**
	 * This method initializes jFrame
	 * 
	 * @return javax.swing.JFrame
	 */
	private JFrame getJFrame() {
		if (jFrame == null) {
			jFrame = new JFrame();
			jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jFrame.setResizable(false);
			jFrame.setAlwaysOnTop(true);
			jFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/ferheng/pivaz.gif")));
			jFrame.setBounds(new Rectangle(InitPivaz.getLocationX(), InitPivaz.getLocationY() , 222, 102));
			jFrame.setJMenuBar(getJJMenuBar());
			jFrame.setContentPane(getJContentPane());
			jFrame.setTitle("Pivaz");
			jFrame.addWindowListener(new java.awt.event.WindowAdapter() {
				public void windowClosing(java.awt.event.WindowEvent e) {
					InitPivaz.setLocationX(jFrame.getX());
					InitPivaz.setLocationY(jFrame.getY());
					InitPivaz.saveNewSettings();
					System.out.println("windowClosing()"); // TODO Auto-generated Event stub windowClosing()
				}
			});
		}
		return jFrame;
	}

	/**
	 * This method initializes aboutDialog	
	 * 	
	 * @return javax.swing.JDialog
	 */
	private JDialog getAboutDialog() {
		if (aboutDialog == null) {
		aboutDialog = new JDialog(getJFrame(), true);
		aboutDialog.setTitle("About");
		aboutDialog.setResizable(false);
		aboutDialog.setPreferredSize(new Dimension(262, 295));
		aboutDialog.setContentPane(getAboutContentPane());
		}
		return aboutDialog;
	}

}
