package ferheng;

import java.awt.Dimension;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JPanel;

import javax.swing.JTextField;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;
import javax.swing.JTextArea;
import java.awt.event.KeyEvent;
import java.util.Vector;

import javax.swing.SwingConstants;

import locallib.DataQuery;
import locallib.InitPivaz;

public class KtoT extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane1 = null;
	private JTextField jTextField = null;
	private JButton jButton2 = null;
	private JList jList = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JLabel jLabel2 = null;
	private JScrollPane jScrollPane = null;
	private JScrollPane jScrollPane1 = null;
	private JTextArea jTextArea = null;
	private JLabel jLabel3 = null;
	private JLabel jLabel4 = null;
	private JLabel jLabel5 = null;
	private Frame parent;

	/**
	 * @param owner
	 */
	public KtoT(Frame owner) {
		super(owner);
		initialize();
		parent=owner;
		parent.setEnabled(false);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(357, 281);
		this.setContentPane(getJContentPane1());
		this.setTitle("Kurd� - Tirk�");				
		this.setResizable(false);
		this.setPreferredSize(new Dimension(357, 281));
		this.addWindowListener(new java.awt.event.WindowAdapter() {   
			public void windowOpened(java.awt.event.WindowEvent e) {    
				System.out.println("windowOpened()"); // TODO Auto-generated Event stub windowOpened()
				
			}
			public void windowClosing(java.awt.event.WindowEvent e) {
				parent.setEnabled(true);
				System.out.println("windowClosing()"); // TODO Auto-generated Event stub windowClosing()
			}
		});		
	}

	/**
	 * This method initializes jContentPane1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane1() {
		if (jContentPane1 == null) {
			jLabel5 = new JLabel();
			jLabel5.setBounds(new Rectangle(174, 0, 27, 20));
			jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel5.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel5.setText("�");
			jLabel5.setForeground(InitPivaz.getTextColor());
			jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseExited(java.awt.event.MouseEvent e) {
					jLabel5.setFont(new Font("Arial", Font.BOLD, 12));
					
				}

				public void mouseEntered(java.awt.event.MouseEvent e) {
					jLabel5.setFont(new Font("Arial", Font.BOLD, 20));
					
				}

				public void mouseClicked(java.awt.event.MouseEvent e) {
					jTextField.setText(jTextField.getText() + "�");
					if(!(jTextField.getText().isEmpty())){					
						jList.setListData(DataQuery.SearchKurdishWords(jTextField.getText()));
						jList.setSelectedIndex(0);						
					} else {
						jList.setListData(new Vector<String>());
						jTextArea.setText("");
					}
					
				}
			});
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(147, 0, 27, 20));
			jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel4.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel4.setText("�");
			jLabel4.setForeground(InitPivaz.getTextColor());
			jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseExited(java.awt.event.MouseEvent e) {
					jLabel4.setFont(new Font("Arial", Font.BOLD, 12));
				
				}

				public void mouseEntered(java.awt.event.MouseEvent e) {
					jLabel4.setFont(new Font("Arial", Font.BOLD, 20));
					
				}

				public void mouseClicked(java.awt.event.MouseEvent e) {
					jTextField.setText(jTextField.getText() + "�");
					if(!(jTextField.getText().isEmpty())){					
						jList.setListData(DataQuery.SearchKurdishWords(jTextField.getText()));
						jList.setSelectedIndex(0);						
					} else {
						jList.setListData(new Vector<String>());
						jTextArea.setText("");
					}
					
				}
			});
			jLabel3 = new JLabel();
			jLabel3.setBounds(new Rectangle(120, 0, 27, 20));
			jLabel3.setForeground(InitPivaz.getTextColor());
			jLabel3.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
			jLabel3.setText("�");
			jLabel3.setFont(new Font("Arial", Font.BOLD, 12));
			jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseExited(java.awt.event.MouseEvent e) {
					jLabel3.setFont(new Font("Arial", Font.BOLD, 12));
					
				}

				public void mouseEntered(java.awt.event.MouseEvent e) {
					jLabel3.setFont(new Font("Arial", Font.BOLD, 20));
				
				}

				public void mouseClicked(java.awt.event.MouseEvent e) {
					jTextField.setText(jTextField.getText() + "�");
					if(!(jTextField.getText().isEmpty())){					
						jList.setListData(DataQuery.SearchKurdishWords(jTextField.getText()));
						jList.setSelectedIndex(0);						
					} else {
						jList.setListData(new Vector<String>());
						jTextArea.setText("");
					}
					
				}
			});
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(182, 49, 110, 20));
			jLabel2.setText("Wateya Tirk�");
			jLabel2.setForeground(InitPivaz.getTextColor());
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(10, 49, 129, 20));
			jLabel1.setForeground(InitPivaz.getTextColor());
			jLabel1.setText("Peyv�n Kurd�");
			jLabel1.setFont(new Font("Dialog", Font.BOLD, 12));
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(10, 0, 72, 20));
			jLabel.setText("Peyva");
			jLabel.setForeground(InitPivaz.getTextColor());
			jContentPane1 = new JPanel();
			jContentPane1.setLayout(null);
			jContentPane1.setBackground(InitPivaz.getBackColor());
			jContentPane1.add(getJTextField(), null);
			jContentPane1.add(getJButton2(), null);
			jContentPane1.add(getJList(), null);
			jContentPane1.add(jLabel, null);
			jContentPane1.add(jLabel1, null);
			jContentPane1.add(jLabel2, null);
			jContentPane1.add(getJScrollPane(), null);
			jContentPane1.add(getJScrollPane1(), null);
			jContentPane1.add(jLabel3, null);
			jContentPane1.add(jLabel4, null);
			jContentPane1.add(jLabel5, null);
		}
		return jContentPane1;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setBounds(new Rectangle(9, 19, 224, 28));
			jTextField.setFont(new Font("Dialog", Font.BOLD, 13));
			jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyReleased(java.awt.event.KeyEvent e) {
					if(!(jTextField.getText().isEmpty())){					
						jList.setListData(DataQuery.SearchKurdishWords(jTextField.getText()));
						jList.setSelectedIndex(0);						
					} else {
						jList.setListData(new Vector<String>());
						jTextArea.setText("");
					}
					System.out.println("keyReleased()"); // TODO Auto-generated Event stub keyReleased()
				}
			});
		}
		return jTextField;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(254, 10, 86, 40));
			jButton2.setText("Temam");
			jButton2.setBackground(InitPivaz.getButonColor());
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					parent.setEnabled(true);
					setVisible(false);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton2;
	}

	/**
	 * This method initializes jList	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJList() {
		if (jList == null) {
			jList = new JList();
			jList.setFont(new Font("Dialog", Font.BOLD, 13));
			jList.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if (jList.getSelectedValue()!= null) 
						jTextField.setText(jList.getSelectedValue().toString());
					System.out.println("mouseClicked()"); // TODO Auto-generated Event stub mouseClicked()
				}
			});
			jList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
				public void valueChanged(javax.swing.event.ListSelectionEvent e) {
					if (jList.getSelectedValue()!= null) {
					jTextArea.setText(DataQuery.SearchKurdishWord(jList.getSelectedValue().toString()));
					}
					else jTextArea.setText("");
					System.out.println("valueChanged()"); // TODO Auto-generated Event stub valueChanged()
				}
			});
		}
		return jList;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane(getJList());
			jScrollPane.setBounds(new Rectangle(9, 70, 163, 170));
			jScrollPane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED), BorderFactory.createBevelBorder(BevelBorder.RAISED)));
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setFont(new Font("Dialog", Font.BOLD, 12));
			jTextArea.setWrapStyleWord(true);
			jTextArea.setLineWrap(true);
		}
		return jTextArea;
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane(getJTextArea());
			jScrollPane1.setBounds(new Rectangle(181, 70, 162, 170));
			jScrollPane1.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED), BorderFactory.createBevelBorder(BevelBorder.RAISED)));
			jScrollPane1.setViewportView(getJTextArea());
		}
		return jScrollPane1;
	}

}
