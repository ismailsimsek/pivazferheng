package locallib;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.sun.corba.se.impl.orbutil.closure.Constant;

public class InitPivaz {
	public static String settings_fiename="pivaz_properties.ini";
	public static String language_fiename="languages/TR.ini";
	public static Color textColor, backColor, butonColor, menuColor;
	public static int locationX = 0 ;
	public static int locationY= 0;
	public static String language ="TR";

	public InitPivaz() {
		super();
		ReadSettings();
		LoadLanguage();
		// TODO Auto-generated constructor stub
	}

	public static void LoadLanguage() {
		language_fiename="languages/"+language+".ini";
	}

	public static void ReadSettings() {

		java.util.Properties property = new java.util.Properties();
		FileInputStream a = null;
		try {
			a = new FileInputStream(settings_fiename);
		} catch (FileNotFoundException e1) {
			InitPivaz.createSettingsFile();
			e1.printStackTrace();
			InitPivaz.ReadSettings();
		}
		try {
			property.load(a);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		locationX = Integer.parseInt(property.getProperty("konumx").toString());
		locationY = Integer.parseInt(property.getProperty("konumy").toString());
		butonColor = new Color(Integer.parseInt(property.getProperty("br")
				.toString()), Integer.parseInt(property.getProperty("bg")
				.toString()), Integer.parseInt(property.getProperty("bb")
				.toString()));
		backColor = new Color(Integer.parseInt(property.getProperty("ar")
				.toString()), Integer.parseInt(property.getProperty("ag")
				.toString()), Integer.parseInt(property.get("ab").toString()));
		textColor = new Color(Integer.parseInt(property.getProperty("yr")
				.toString()), Integer.parseInt(property.getProperty("yg")
				.toString()), Integer.parseInt(property.get("yb").toString()));
		menuColor = new Color(Integer.parseInt(property.getProperty("mr")
				.toString()), Integer.parseInt(property.getProperty("mg")
				.toString()), Integer.parseInt(property.get("mb").toString()));
	}

	protected static void createSettingsFile() {

		java.util.Properties property = new java.util.Properties();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(settings_fiename);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		property.setProperty("konumx", "50");
		property.setProperty("konumy", "50");
		property.setProperty("br", "178");
		property.setProperty("bg", "178");
		property.setProperty("bb", "178");
		property.setProperty("ar", "210");
		property.setProperty("ag", "210");
		property.setProperty("ab", "210");
		property.setProperty("yr", "255");
		property.setProperty("yg", "255");
		property.setProperty("yb", "255");
		property.setProperty("mr", "255");
		property.setProperty("mg", "255");
		property.setProperty("mb", "255");

		try {
			property.store(fos, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Color getButonColor() {
		return butonColor;
	}

	public static void setButonColor(Color butonColor) {
		InitPivaz.butonColor = butonColor;
	}

	public static Color getTextColor() {
		return textColor;
	}

	public static void setTextColor(Color textColor) {
		InitPivaz.textColor = textColor;
	}

	public static int getLocationX() {
		return locationX;
	}

	public static int getPozitifLocationX() {
		if (locationX < 0)
			return 0;
		else
			return locationX;
	}

	public static void setLocationX(int locX) {
		locationX = locX;
	}

	public static int getLocationY() {
		return locationY;
	}

	public static int getPozitifLocationY() {
		if (locationY < 0)
			return 0;
		else
			return locationY;
	}

	public static void setLocationY(int locY) {
		locationY = locY;
	}

	public static void saveNewSettings() {

		java.util.Properties property = new java.util.Properties();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(settings_fiename);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		property.setProperty("konumx", locationX + "");
		property.setProperty("konumy", locationY + "");
		property.setProperty("br", butonColor.getRed() + "");
		property.setProperty("bg", butonColor.getGreen() + "");
		property.setProperty("bb", butonColor.getBlue() + "");
		property.setProperty("ar", backColor.getRed() + "");
		property.setProperty("ag", backColor.getGreen() + "");
		property.setProperty("ab", backColor.getBlue() + "");
		property.setProperty("yr", textColor.getRed() + "");
		property.setProperty("yg", textColor.getGreen() + "");
		property.setProperty("yb", textColor.getBlue() + "");
		property.setProperty("mr", menuColor.getRed() + "");
		property.setProperty("mg", menuColor.getGreen() + "");
		property.setProperty("mb", menuColor.getBlue() + "");

		try {
			property.store(fos, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Color getBackColor() {
		return backColor;
	}

	public static void setBackColor(Color backColor) {
		InitPivaz.backColor = backColor;
	}

	public static Color getMenuColor() {
		return menuColor;
	}

	public static void setMenuColor(Color menuColor) {
		InitPivaz.menuColor = menuColor;
	}

}
