package locallib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JOptionPane;

public class DataQuery {

	protected static Statement st; // @jve:decl-index=0:
	protected static ResultSet sonuc = null;
	private static Vector<String> Turkishresults = new Vector<String>(); 
	// @jve:decl-index=0:
	private static Vector<String> Kurdishresults = new Vector<String>(); 
	// @jve:decl-index=0:
	
	public DataQuery() {		
		try {
			 Class.forName("org.hsqldb.jdbcDriver");

		} catch (java.lang.ClassNotFoundException eror) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(eror.getMessage());
		}
		try {
			Connection	con = DriverManager.getConnection("jdbc:hsqldb:file:"+"\\home\\ismail\\workspace\\Pivaz\\pivaz.odb", "sa", "");
			st = con.createStatement();
		} catch (SQLException ex) {

			JOptionPane.showMessageDialog(null,"err 1");
			JOptionPane.showMessageDialog(null,"Database Connection Error !!!\n " +
					"can't create connection with the data !!!\n " );
			System.err.println("SQLException:" + ex.getMessage());
			// System.exit(0);					
		}		
	}
	
	
	/*public static void winconnectSql(){
		//		connecting mdb
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			System.out.println("Connected mdb ...");

		} catch (java.lang.ClassNotFoundException eror) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(eror.getMessage());			
		}
		try {
			Connection	con = DriverManager.getConnection("jdbc:odbc:F2", "", "");
			st = con.createStatement();
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Database Connection Error !!!\n " +
					"can't create connection with the data !!!\n " +
					"if you are a windows user tray to adding F2.mdb to your ODBC Driver...\n" +
					"C/program files/Pivaz/F2.mdb Default path.");
			System.err.println("SQLException:" + ex.getMessage());
			// System.exit(0);					
		}
	}*/
	
	

	public static Vector<String> SearchKurdishWords(String searchString) {
		try {
			String query = "SELECT kk FROM kkta WHERE kk LIKE '" + searchString + "%'";
			sonuc = st.executeQuery(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Turkishresults.removeAllElements();
		try {
			while (sonuc.next())
				Turkishresults.add(sonuc.getObject(1).toString());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		return Turkishresults;
	}

	public static Vector<String> SearchTurkishWords(String searchString) {
		try {
			String	query = "SELECT tk FROM tkka WHERE tk LIKE '" + searchString + "%'";
			sonuc = st.executeQuery(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		Kurdishresults.removeAllElements();
		try {
			while (sonuc.next())
				Kurdishresults.add(sonuc.getObject(1).toString());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return Kurdishresults;
	}
	
	public static String SearchKurdishWord(String word) {
		String res="";
		String	query = "SELECT ta FROM kkta WHERE kk ='"
						+ word + "'";
				try {
					sonuc = st.executeQuery(query);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
			
				try {
					while (sonuc.next())
						res+=sonuc.getObject(1).toString();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		return res;
	}

	public static String SearchTurkishWord(String word) {
		String res="";
		String query = "SELECT ka FROM tkka WHERE tk ='"
			+ word + "'";
	try {
		sonuc = st.executeQuery(query);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		

	try {
		while (sonuc.next())
			res+=sonuc.getObject(1).toString();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return res;
	}
	
}
